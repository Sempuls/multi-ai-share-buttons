# Changelog

All notable changes to Multi AI Share Buttons will be documented in this file.

## [3.9.0] - 2025-02-16

### Added
- ✨ **3 style wizualne:** Premium, Minimal, Minimal Colored
- 🎨 Minimalistyczny Kolorowy - nowy styl z kolorowymi ramkami brand
- 🔄 **Automatyczne aktualizacje z GitHub**
- 📦 System update checker dla WordPress
- 🎯 Wybór stylu przycisków w panelu admina
- 📱 Pełna responsywność dla wszystkich stylów
- 🌙 Dark mode support

### Fixed
- 🐛 Naprawiono pętlę rekurencyjną przy pobieraniu excerpt
- 🔒 Poprawiono bezpieczeństwo (nonce, escape)
- 💾 Optymalizacja cache dla inline CSS
- ✅ Walidacja post ID w AJAX

### Changed
- 🎨 Przeprojektowano wszystkie style CSS
- 📝 Zaktualizowano dokumentację
- 🚀 Zwiększono wydajność ładowania

## [3.8.0] - 2025-02-15

### Added
- 🎨 Dwa style wizualne: Premium i Minimal
- ⚙️ Przełącznik stylów w panelu admina
- 🎬 Animacje fade-in dla przycisków Premium
- 📊 Plik PREVIEW.html z porównaniem stylów

## [3.7.5] - 2025-02-15

### Added
- 🛍️ Produkty WooCommerce domyślnie włączone
- 📝 Opcja własnego tekstu nagłówka
- 🎨 Premium style z gradientami

### Fixed
- 🐛 Usunięto duplikację CSS w wp_head
- 🔒 Dodano nonce dla AJAX requests

## [3.7.4] - 2025-02-15

### Removed
- 🗑️ Usunięto funkcjonalność JSON-LD (SEO)

## [3.7.3] - 2025-02-15

### Fixed
- 🐛 **Naprawiono nieskończoną pętlę rekurencyjną**
- ⚡ Bezpieczne pobieranie excerpt bez filtrów

### Added
- 🛡️ Flaga zabezpieczająca przed rekurencją
- 📝 Manualne generowanie excerpt z post_content

## [3.7.0-3.7.2] - 2025-02-14

### Added
- 🤖 10 platform AI (ChatGPT, Claude, Perplexity, Gemini, etc.)
- ⚙️ Pełny panel konfiguracyjny
- 🎯 Wybór typów wpisów
- 📍 Wybór pozycji przycisków
- 🚫 Wykluczanie stron
- 📊 Google Analytics tracking
- 🎨 Podstawowe style CSS

---

## Template for new releases:

```markdown
## [X.X.X] - YYYY-MM-DD

### Added
- New features

### Fixed
- Bug fixes

### Changed
- Changes in existing functionality

### Deprecated
- Soon-to-be removed features

### Removed
- Removed features

### Security
- Security fixes
```
