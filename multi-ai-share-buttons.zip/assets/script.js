/**
 * Multi AI Share Buttons - Lazy Loading Script
 * Version: 3.7.1
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Find all placeholders
        $('.multi-share-buttons-placeholder, #multi-share-buttons-placeholder').each(function() {
            var $placeholder = $(this);
            var postId = $placeholder.data('postid');
            var nonce = $placeholder.data('nonce');

            // Validate data
            if (!postId || !nonce) {
                console.error('Multi Share Buttons: Missing post ID or nonce');
                return;
            }

            // Load buttons via AJAX
            $.ajax({
                url: multiShareButtons.ajax_url,
                type: 'GET',
                data: {
                    action: 'multi_share_buttons_load',
                    postid: postId,
                    nonce: nonce
                },
                success: function(response) {
                    // Replace placeholder with actual buttons
                    $placeholder.replaceWith(response);
                },
                error: function(xhr, status, error) {
                    console.error('Multi Share Buttons AJAX Error:', error);
                    // Remove placeholder on error
                    $placeholder.remove();
                }
            });
        });

        // Track button clicks (if Google Analytics is available)
        $(document).on('click', '.multi-share-buttons .btn', function() {
            var buttonName = $(this).data('button');
            var postId = $(this).data('postid');

            // Optional: Console log for debugging
            if (window.console && window.console.log) {
                console.log('AI Button clicked:', buttonName, 'Post ID:', postId);
            }

            // Track with Google Analytics if available
            if (typeof gtag !== 'undefined') {
                gtag('event', 'klikniecie_ai_przycisku', {
                    event_category: 'AI Buttons',
                    event_label: buttonName,
                    value: postId
                });
            }

            // Track with Google Analytics (old analytics.js) if available
            if (typeof ga !== 'undefined') {
                ga('send', 'event', 'AI Buttons', 'Click', buttonName);
            }
        });
    });

})(jQuery);
