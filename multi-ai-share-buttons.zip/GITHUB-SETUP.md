# Multi AI Share Buttons - Auto-Update Guide

## 🔄 Jak działa automatyczna aktualizacja

Ta wtyczka sprawdza GitHub co 12 godzin. Gdy wykryje nową wersję, WordPress automatycznie pokaże dostępną aktualizację.

---

## 📋 Instrukcja konfiguracji GitHub (jednorazowa)

### Krok 1: Stwórz repozytorium GitHub

1. Idź na: https://github.com/new
2. Nazwa: `multi-ai-share-buttons`
3. Widoczność: **Public** (dla darmowych aktualizacji)
4. Kliknij **Create repository**

### Krok 2: Upload kodu

```bash
# W folderze wtyczki
git init
git add .
git commit -m "Initial commit v3.9.0"
git branch -M main
git remote add origin https://github.com/TWOJE_KONTO/multi-ai-share-buttons.git
git push -u origin main
```

### Krok 3: Edytuj plik główny

Otwórz `multi-ai-share-buttons.php` i zamień:

```php
new MultiAI_Update_Checker(
    __FILE__,
    'TWOJE_KONTO',           // ← ZMIEŃ NA SWOJĄ NAZWĘ
    'multi-ai-share-buttons'
);
```

**Przykład:**
```php
new MultiAI_Update_Checker(
    __FILE__,
    'jankowalski',           // Twoja nazwa użytkownika GitHub
    'multi-ai-share-buttons'
);
```

---

## 🚀 Jak wydać nową wersję (aktualizacja)

### Sposób 1: Przez interfejs GitHub (najłatwiejszy)

1. Edytuj kod lokalnie
2. Zmień numer wersji w `multi-ai-share-buttons.php`:
   ```php
   * Version: 3.10.0
   ```
3. Commit i push:
   ```bash
   git add .
   git commit -m "Update to v3.10.0"
   git push
   ```
4. Idź na GitHub → **Releases** → **Create a new release**
5. **Tag version:** `v3.10.0` (z literą 'v')
6. **Release title:** `Version 3.10.0`
7. **Description:** Opisz zmiany
8. Kliknij **Publish release**

### Sposób 2: Przez terminal (dla zaawansowanych)

```bash
# Zmień wersję w pliku
# Potem:
git add .
git commit -m "Release v3.10.0"
git tag v3.10.0
git push origin main --tags
```

Następnie stwórz Release w interfejsie GitHub.

---

## 📦 Ważne: Dodaj ZIP do Release

GitHub automatycznie tworzy ZIP, ALE musisz:

1. Stwórz Release (jak powyżej)
2. GitHub automatycznie doda `Source code (zip)`
3. **To wystarczy!** Wtyczka pobierze ten ZIP

---

## ✅ Weryfikacja

Po stworzeniu Release:

1. Idź do WordPress → **Dashboard → Aktualizacje**
2. Po ~12h powinna pojawić się dostępna aktualizacja
3. Lub wymuś sprawdzenie: usuń transient
   ```php
   delete_transient('multi_ai_update_' . md5('multi-ai-share-buttons'));
   ```

---

## 🎯 Przykładowy harmonogram wydań

```
v3.9.0  - Aktualna wersja
v3.10.0 - Dodano wybór AI
v3.11.0 - Dodano ikony
v4.0.0  - Major update
```

---

## 🔒 Prywatne repozytorium (opcjonalne)

Jeśli chcesz **prywatne** repo:

1. Stwórz Personal Access Token na GitHub
2. Dodaj do update checkera:
   ```php
   new MultiAI_Update_Checker(
       __FILE__,
       'TWOJE_KONTO',
       'multi-ai-share-buttons',
       'ghp_TWOJ_TOKEN'  // GitHub token
   );
   ```

**Bez tokenu = tylko publiczne repo.**

---

## 📝 Changelog Format

W każdym Release opisz zmiany:

```markdown
## v3.10.0

### Nowe funkcje
- Wybór konkretnych AI do wyświetlenia
- Ikony obok nazw AI
- Widget dla sidebar

### Poprawki
- Naprawiono błąd w mobile view
- Zwiększono wydajność cache

### Zmiany
- Zaktualizowano style minimal-colored
```

---

## 🆘 Troubleshooting

### Aktualizacja się nie pokazuje

1. Sprawdź czy Release ma ZIP
2. Sprawdź czy tag zaczyna się od `v` (v3.10.0)
3. Wymuś sprawdzenie (usuń transient)
4. Poczekaj 12h (cache)

### Błąd przy pobieraniu

1. Sprawdź czy repo jest Public
2. Sprawdź czy ZIP istnieje w Assets
3. Sprawdź logi: `wp-content/debug.log`

---

## 🎉 Gotowe!

Teraz każda aktualizacja to:
1. Push code → GitHub
2. Create Release
3. WordPress automatycznie wykryje update!

**Zero ręcznego uploadowania plików!** 🚀
