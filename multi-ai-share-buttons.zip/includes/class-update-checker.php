<?php
/**
 * Plugin Update Checker for GitHub
 * Lightweight version for multi-ai-share-buttons
 * Based on YahnisElsts/plugin-update-checker
 */

if (!class_exists('MultiAI_Update_Checker')) {
    
    class MultiAI_Update_Checker {
        
        private $plugin_file;
        private $github_username;
        private $github_repo;
        private $plugin_slug;
        
        public function __construct($plugin_file, $github_username, $github_repo) {
            $this->plugin_file = $plugin_file;
            $this->github_username = $github_username;
            $this->github_repo = $github_repo;
            $this->plugin_slug = plugin_basename($plugin_file);
            
            // Hook into WordPress update system
            add_filter('pre_set_site_transient_update_plugins', [$this, 'check_for_update']);
            add_filter('plugins_api', [$this, 'plugin_info'], 10, 3);
        }
        
        /**
         * Check GitHub for new version
         */
        public function check_for_update($transient) {
            if (empty($transient->checked)) {
                return $transient;
            }
            
            // Get remote version
            $remote_version = $this->get_remote_version();
            
            if (!$remote_version) {
                return $transient;
            }
            
            // Get current version
            $plugin_data = get_plugin_data($this->plugin_file);
            $current_version = $plugin_data['Version'];
            
            // Compare versions
            if (version_compare($current_version, $remote_version, '<')) {
                $plugin_info = $this->get_plugin_info();
                
                if ($plugin_info) {
                    $transient->response[$this->plugin_slug] = (object) [
                        'slug' => dirname($this->plugin_slug),
                        'new_version' => $remote_version,
                        'package' => $plugin_info->download_url,
                        'url' => $plugin_info->html_url,
                        'tested' => '6.7',
                        'requires_php' => '7.4',
                    ];
                }
            }
            
            return $transient;
        }
        
        /**
         * Get remote version from GitHub
         */
        private function get_remote_version() {
            $transient_key = 'multi_ai_update_' . md5($this->github_repo);
            $cached = get_transient($transient_key);
            
            if ($cached !== false) {
                return $cached;
            }
            
            $url = sprintf(
                'https://api.github.com/repos/%s/%s/releases/latest',
                $this->github_username,
                $this->github_repo
            );
            
            $response = wp_remote_get($url, [
                'timeout' => 10,
                'headers' => [
                    'Accept' => 'application/vnd.github.v3+json',
                ]
            ]);
            
            if (is_wp_error($response)) {
                return false;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body);
            
            if (!isset($data->tag_name)) {
                return false;
            }
            
            // Remove 'v' prefix if exists (v3.9.0 -> 3.9.0)
            $version = ltrim($data->tag_name, 'v');
            
            // Cache for 12 hours
            set_transient($transient_key, $version, 12 * HOUR_IN_SECONDS);
            
            return $version;
        }
        
        /**
         * Get plugin info from GitHub
         */
        private function get_plugin_info() {
            $url = sprintf(
                'https://api.github.com/repos/%s/%s/releases/latest',
                $this->github_username,
                $this->github_repo
            );
            
            $response = wp_remote_get($url, [
                'timeout' => 10,
                'headers' => [
                    'Accept' => 'application/vnd.github.v3+json',
                ]
            ]);
            
            if (is_wp_error($response)) {
                return false;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body);
            
            if (!isset($data->assets) || empty($data->assets)) {
                return false;
            }
            
            // Find ZIP asset
            foreach ($data->assets as $asset) {
                if (strpos($asset->name, '.zip') !== false) {
                    $data->download_url = $asset->browser_download_url;
                    break;
                }
            }
            
            return $data;
        }
        
        /**
         * Plugin information for update screen
         */
        public function plugin_info($false, $action, $args) {
            if ($action !== 'plugin_information') {
                return $false;
            }
            
            if (!isset($args->slug) || $args->slug !== dirname($this->plugin_slug)) {
                return $false;
            }
            
            $plugin_info = $this->get_plugin_info();
            
            if (!$plugin_info) {
                return $false;
            }
            
            $plugin_data = get_plugin_data($this->plugin_file);
            
            return (object) [
                'name' => $plugin_data['Name'],
                'slug' => dirname($this->plugin_slug),
                'version' => ltrim($plugin_info->tag_name, 'v'),
                'author' => $plugin_data['Author'],
                'homepage' => $plugin_info->html_url,
                'download_link' => $plugin_info->download_url,
                'sections' => [
                    'description' => $plugin_data['Description'],
                    'changelog' => $this->parse_changelog($plugin_info->body),
                ],
                'tested' => '6.7',
                'requires_php' => '7.4',
            ];
        }
        
        /**
         * Parse GitHub release notes to changelog
         */
        private function parse_changelog($body) {
            if (empty($body)) {
                return 'See GitHub releases for changelog.';
            }
            
            // Convert markdown to basic HTML
            $body = str_replace('###', '<h3>', $body);
            $body = str_replace('##', '<h2>', $body);
            $body = str_replace('*', '<li>', $body);
            $body = nl2br($body);
            
            return $body;
        }
    }
}
