# Multi AI Share Buttons - WordPress Plugin

![Version](https://img.shields.io/badge/version-3.7.5-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0%2B-green.svg)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-purple.svg)

Profesjonalna wtyczka WordPress dodająca przyciski do wysyłania treści postów do popularnych AI (ChatGPT, Claude, Perplexity, Gemini i więcej).

## ✨ Funkcje

- 🤖 **10 platform AI**: ChatGPT, Perplexity, Grok, Google AI, Gemini, Copilot, Claude, Meta AI, Mistral, DeepSeek
- 🎨 **Premium design**: Gradienty, animacje, nowoczesny wygląd
- ⚡ **Wydajność**: Bez pętli rekurencyjnych, zoptymalizowany kod
- 📱 **Responsywność**: Działa na desktop, tablet i mobile
- 🔧 **Konfigurowalność**: Panel administracyjny z wieloma opcjami
- 🎯 **Elastyczność**: Wybór typów wpisów, pozycji, wykluczenia
- 📊 **Tracking**: Integracja z Google Analytics
- 🌐 **SEO**: Poprawne atrybuty rel="nofollow noopener"

## 📦 Instalacja

### Metoda 1: Przez panel WordPress (zalecana)

1. Pobierz plik `multi-ai-share-buttons.zip`
2. W WordPress przejdź do: **Wtyczki → Dodaj nową → Wyślij wtyczkę na serwer**
3. Wybierz plik ZIP i kliknij **Zainstaluj**
4. Aktywuj wtyczkę

### Metoda 2: Ręczna instalacja

1. Wypakuj folder `multi-ai-share-buttons`
2. Prześlij przez FTP do: `/wp-content/plugins/`
3. W WordPress aktywuj wtyczkę

## ⚙️ Konfiguracja

Po aktywacji przejdź do: **Ustawienia → Share Buttons**

### Dostępne opcje:

#### **Typy wpisów**
- ☑️ Wpisy (Posts)
- ☑️ Strony (Pages)
- ☑️ Produkty (Products) - domyślnie włączone
- ☑️ Własne typy wpisów (Custom Post Types)

#### **Pozycja przycisków**
- Przed treścią
- Po treści (domyślnie)
- Przed i po treści

#### **Wykluczenia**
- Strona główna
- Konkretne strony (po ID lub slug)
  - Przykład: `123, 456, kontakt, o-nas`

#### **Opcje zapytania**
- ✅ Dodawaj tytuł wpisu
- ✅ Dodawaj słowa kluczowe (tagi)
- ✅ Preferuj cytowanie źródła
- 📝 Własny szablon zapytania

#### **Wygląd**
- 🎨 Wyśrodkowanie przycisków
- 📝 Własny tekst nagłówka
- 💾 Inline CSS (bez zewnętrznego pliku)

## 🎨 Przykład użycia

### Automatyczne wyświetlanie

Przyciski wyświetlają się automatycznie na włączonych typach wpisów.

### Shortcode

Użyj w edytorze lub szablonie:

```php
[multi_share_buttons]
```

Lub w kodzie PHP:

```php
<?php echo do_shortcode('[multi_share_buttons]'); ?>
```

## 🔧 Struktura plików

```
multi-ai-share-buttons/
├── multi-ai-share-buttons.php    # Główny plik wtyczki
├── assets/
│   ├── style.css                 # Style CSS
│   └── script.js                 # JavaScript (opcjonalny)
└── README.md                      # Ten plik
```

## 🎯 Obsługiwane platformy AI

| Platforma | URL | Kolor |
|-----------|-----|-------|
| ChatGPT | chat.openai.com | Zielony gradient |
| Perplexity | perplexity.ai | Niebieski gradient |
| Grok | x.com/i/grok | Twitter blue |
| Google AI | google.com/search | Google blue |
| Gemini AI | gemini.google.com | Fioletowy |
| Copilot | copilot.microsoft.com | Microsoft blue |
| Claude | claude.ai | Pomarańczowy |
| Meta AI | meta.ai | Meta blue |
| Mistral | chat.mistral.ai | Czerwony |
| DeepSeek | chat.deepseek.com | Ciemny |

## 📊 Tracking

Wtyczka automatycznie trackuje kliknięcia w Google Analytics (jeśli zainstalowany):

```javascript
gtag('event', 'klikniecie_ai_przycisku', {
    event_category: 'AI Buttons',
    event_label: 'ChatGPT',
    value: post_id
});
```

## 🔄 Changelog

### Version 3.7.5 (2025-02-16)
- ✨ Dodano produkty WooCommerce jako domyślny typ
- 🎨 Premium style z gradientami
- ⚡ Naprawiono pętlę rekurencyjną
- 🔒 Poprawiono bezpieczeństwo (nonce, escape)
- 🗑️ Usunięto JSON-LD

### Version 3.7.4
- 🗑️ Usunięto funkcjonalność JSON-LD

### Version 3.7.3
- 🐛 Naprawiono nieskończoną pętlę rekurencyjną
- ⚡ Zoptymalizowano pobieranie excerpt

### Version 3.7.1
- 🔒 Dodano weryfikację nonce w AJAX
- 🐛 Poprawiono escape XSS w onclick
- 💾 Cache dla inline CSS

## 💡 Wsparcie

**Autor**: visomedia.pl  
**Wersja**: 3.7.5  
**Wymaga**: WordPress 5.0+, PHP 7.4+

## 📝 Licencja

GPL v2 lub nowsza

---

**Dziękujemy za korzystanie z Multi AI Share Buttons!** 🎉
